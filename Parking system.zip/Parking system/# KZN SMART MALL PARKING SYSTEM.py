# KZN SMART MALL PARKING SYSTEM
import time
import math

GATEWAY_PRICE = 15
PAVILION_PRICE = 10
LALUCIA_PRICE = 12

MALLS = {"1": "Gateway", "2": "Pavilion", "3": "La Lucia"}

USER_FILE = "users.txt"
PARKING_FILE = "parking.txt"

total_customers = 0
total_money = 0

def load_users():
    users = []
    try:
        with open(USER_FILE, "r") as f:
            for line in f:
                line = line.strip()
                if line:
                    parts = line.split(",")
                    if len(parts) == 2:
                        u, p = parts
                        users.append({"username": u, "password": p, "role": "user", "mall": ""})
                    elif len(parts) == 3:
                        u, p, r = parts
                        users.append({"username": u, "password": p, "role": r, "mall": ""})
                    else:
                        u, p, r, m = parts
                        users.append({"username": u, "password": p, "role": r, "mall": m})

        usernames = [u["username"] for u in users]
        if "admin1" not in usernames:
            with open(USER_FILE, "a") as f:
                f.write("admin1,admin123,admin,1\n")
                f.write("admin2,admin123,admin,2\n")
                f.write("admin3,admin123,admin,3\n")
                f.write("owner,owner123,owner,\n")
            users.extend([
                {"username": "admin1", "password": "admin123", "role": "admin", "mall": "1"},
                {"username": "admin2", "password": "admin123", "role": "admin", "mall": "2"},
                {"username": "admin3", "password": "admin123", "role": "admin", "mall": "3"},
                {"username": "owner", "password": "owner123", "role": "owner", "mall": ""}
            ])
    except FileNotFoundError:
        with open(USER_FILE, "w") as f:
            f.write("admin1,admin123,admin,1\n")
            f.write("admin2,admin123,admin,2\n")
            f.write("admin3,admin123,admin,3\n")
            f.write("owner,owner123,owner,\n")
        users = [
            {"username": "admin1", "password": "admin123", "role": "admin", "mall": "1"},
            {"username": "admin2", "password": "admin123", "role": "admin", "mall": "2"},
            {"username": "admin3", "password": "admin123", "role": "admin", "mall": "3"},
            {"username": "owner", "password": "owner123", "role": "owner", "mall": ""}
        ]
    return users

def save_user(username, password):
    with open(USER_FILE, "a") as f:
        f.write(f"{username},{password},user,\n")

def save_parking(username, mall_id):
    mall_name = MALLS[mall_id]
    entry_time = time.time()
    with open(PARKING_FILE, "a") as f:
        f.write(f"{username},{mall_id},{mall_name},{entry_time},0,0,pending\n")

def load_parking(username):
    try:
        with open(PARKING_FILE, "r") as f:
            for line in f:
                data = line.strip().split(",")
                if len(data) == 7 and data[0] == username and data[6] == "pending":
                    return data
    except FileNotFoundError:
        open(PARKING_FILE, "w").close()
    return None

def load_all_parking():
    try:
        with open(PARKING_FILE, "r") as f:
            return [line.strip().split(",") for line in f if line.strip()]
    except FileNotFoundError:
        open(PARKING_FILE, "w").close()
        return []

def update_parking_status(username, hours, amount, new_status):
    global total_customers, total_money
    lines = []
    try:
        with open(PARKING_FILE, "r") as f:
            lines = f.readlines()
    except FileNotFoundError:
        return
    with open(PARKING_FILE, "w") as f:
        for line in lines:
            data = line.strip().split(",")
            if len(data) == 7 and data[0] == username and data[6] == "pending":
                data[4] = str(hours)
                data[5] = str(amount)
                data[6] = new_status
                f.write(",".join(data) + "\n")
                if new_status == "paid":
                    total_customers += 1
                    total_money += float(amount)
            else:
                f.write(line)

def calculate_amount(mall_id, hours):
    if hours < 1:
        hours = 1
    if mall_id == "1":
        return GATEWAY_PRICE
    elif mall_id == "2":
        return hours * PAVILION_PRICE
    elif mall_id == "3":
        amount = hours * LALUCIA_PRICE
        return 60 if amount > 60 else amount
    return 0

def register():
    print("\nREGISTER")
    username = input("Put username: ")
    password = input("Put password: ")
    users = load_users()
    if any(u["username"] == username for u in users):
        print("Username already exists. Try another one.")
        return
    save_user(username, password)
    print("Registration successful")

def login():
    print("\nLOGIN")
    username = input("Enter username: ")
    password = input("Enter password: ")
    users = load_users()
    for u in users:
        if username == u["username"] and password == u["password"]:
            print(f"Login successful. Role: {u['role']}")
            return u
    print("Wrong username or password")
    return None

def payment(username, mall_id, entry_time_str):
    entry_time = float(entry_time_str)
    exit_time = time.time()

    seconds_parked = exit_time - entry_time
    hours = math.ceil(seconds_parked / 3600)
    if hours < 1:
        hours = 1

    amount = calculate_amount(mall_id, hours)

    print(f"\nHours parked: {hours}")
    print(f"Amount to pay: R{amount}")

    choice = input("Confirm payment? yes/no: ")
    if choice.lower() == 'yes':
        money = float(input("Enter payment amount: R"))
        if money >= amount:
            change = money - amount
            print("Payment successful")
            print("Your Change is: R", change)
            update_parking_status(username, hours, amount, "paid")
        else:
            print("Not enough money. Balance remaining: R", amount - money)
    else:
        update_parking_status(username, hours, amount, "cancelled")
        print("Payment cancelled")

def parking(username):
    if load_parking(username):
        print("You already have a pending parking. Pay or cancel it first.")
        return

    print("\nCUSTOMER DETAILS")
    customer_name = input("Enter customer name: ")
    car_number = input("Enter car registration: ")

    print("\nChoose Mall")
    print("1. Gateway - R15 " \
    "")
    print("2. Pavilion - R10 per hour")
    print("3. La Lucia - R12 per hour")

    mall_id = input("Enter mall number: ")
    if mall_id not in MALLS:
        print("Invalid Mall!")
        return

    save_parking(username, mall_id)
    print(f"\nParking recorded at {MALLS[mall_id]}")
    print("Login again when you come back to pay.")

def view_history(username):
    print("\nPARKING HISTORY")
    parkings = load_all_parking()
    found = False
    for p in parkings:
        if p[0] == username:
            found = True
            print(f"Mall: {p[2]}, Hours: {p[4]}, Amount: R{p[5]}, Status: {p[6]}")
    if not found:
        print("No parking history found.")

def view_mall_parkings(mall_id):
    print(f"\n{MALLS[mall_id]} PARKING RECORDS")
    parkings = load_all_parking()
    found = False
    print(f"{'User':<10} {'Mall':<12} {'Hours':<6} {'Amount':<8} {'Status':<10}")
    total = 0
    for p in parkings:
        if len(p) == 7 and p[1] == mall_id:
            found = True
            print(f"{p[0]:<10} {p[2]:<12} {p[4]:<6} R{p[5]:<7} {p[6]:<10}")
            if p[6] == "paid":
                total += float(p[5])
    if not found:
        print("No records for this mall")
    else:
        print("Total Paid: R", total)

def view_all_parkings():
    print("\nALL MALLS PARKING RECORDS")
    parkings = load_all_parking()
    if not parkings:
        print("No records yet")
        return
    print(f"{'User':<10} {'Mall':<12} {'Hours':<6} {'Amount':<8} {'Status':<10}")
    total = 0
    for p in parkings:
        if len(p) == 7:
            print(f"{p[0]:<10} {p[2]:<12} {p[4]:<6} R{p[5]:<7} {p[6]:<10}")
            if p[6] == "paid":
                total += float(p[5])
    print("Total Paid: R", total)

def report():
    print("\nREPORT")
    print("Total Customers:", total_customers)
    print("Total Money Made: R", total_money)
    if total_customers > 0:
        average = total_money / total_customers
        print("Average Payment: R", round(average, 2))
    else:
        print("No customers yet")

while True:
    print("\nKZN SMART MALL PARKING SYSTEM")
    print("1. Register")
    print("2. Login")
    print("3. Report")
    print("4. Exit")
    choice = input("Enter choice: ")

    if choice == "1":
        register()
    elif choice == "2":
        user = login()
        if user:
            username = user["username"]
            role = user["role"]
            mall = user["mall"]

            if role == "admin":
                view_mall_parkings(mall)
            elif role == "owner":
                view_all_parkings()
            else:
                pending = load_parking(username)
                if pending:
                    print("\nYou have a car parked:")
                    payment(username, pending[1], pending[3])
                else:
                    print("\n1. Park Car")
                    print("2. View History")
                    sub = input("Enter choice: ")
                    if sub == "1":
                        parking(username)
                    elif sub == "2":
                        view_history(username)
    elif choice == "3":
        report()
    elif choice == "4":
        print("System closing...")
        break
    else:
        print("Invalid choice")